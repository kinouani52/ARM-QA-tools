__copyright__ = """
/*
 * Copyright (c) 2021, Arm Limited. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 *
 */
 """

""" __init__.py:

    __init__.py for complexity parser

"""
