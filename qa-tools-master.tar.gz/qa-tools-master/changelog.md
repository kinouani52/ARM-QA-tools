# v0.1

- first public release
- trace-based coverage tool
- quality metrics measurement and tracking setup
- associated documentation

## License
[BSD-3-Clause](./license.md)
